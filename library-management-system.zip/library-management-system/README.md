## Getting Started

Run from "\src\librarysystem\Main.java"


User: 101  Pass: xyz  Auth: LIBRARIAN

User: 102  Pass: abc  Auth: ADMIN

User: 103  Pass: 111  Auth: BOTH

package business;

final public class Author extends Person {
	private String bio;
	private static final long serialVersionUID = 7508481940058530471L;

	public String getBio() {
		return bio;
	}

	public Author(String f, String l, String t, Address a, String bio) {
		super(f, l, t, a);
		this.bio = bio;
	}
}

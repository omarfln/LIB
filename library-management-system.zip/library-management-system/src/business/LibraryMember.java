// Source code is decompiled from a .class file using FernFlower decompiler.
package business;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import librarysystem.librarienscreens.checkouts.CheckoutRecord;

public final class LibraryMember extends Person implements Serializable {
	private String memberId;
	private static final long serialVersionUID = -2226197306790714013L;
	private List<CheckoutRecord> records;

	public LibraryMember(String memberId, String fname, String lname, String tel, Address add) {
		super(fname, lname, tel, add);
		this.memberId = memberId;
		this.records = new ArrayList<>();
	}

	public void setRecords(List<CheckoutRecord> records) {
		this.records = records;
	}

	public List<CheckoutRecord> getRecords() {
		return this.records;
	}

	public String getMemberId() {
		return this.memberId;
	}

	public String toString() {
		String var10000 = this.memberId;
		return "Member Info: ID: " + var10000 + ", name: " + this.getFirstName() + " " + this.getLastName() + ", "
				+ this.getTelephone() + " " + String.valueOf(this.getAddress());
	}
}

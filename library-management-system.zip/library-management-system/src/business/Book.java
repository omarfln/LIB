package business;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

final public class Book implements Serializable {

	private static final long serialVersionUID = 6110690276685962829L;
	private  BookCopy[] copies;
	private List<Author> authors;
	private String isbn;
	private String title;
	private int maxCheckoutLength;

	public Book(String isbn, String title, int maxCheckoutLength, List<Author> authors) {
		this.isbn = isbn;
		this.title = title;
		this.maxCheckoutLength = maxCheckoutLength;
		this.authors = Collections.unmodifiableList(authors);
		copies = new BookCopy[] { new BookCopy(this, 1, true) };
	}

	public void updateCopies(BookCopy copy) {
		for (int i = 0; i < this.copies.length; ++i) {
			BookCopy c = this.copies[i];
			if (c.equals(copy)) {
				this.copies[i] = copy;

			}
		}
	}

	public List<Integer> getCopyNums() {
		List<Integer> retVal = new ArrayList<>();
		BookCopy[] var5;
		int var4 = (var5 = this.copies).length;

		for (int var3 = 0; var3 < var4; ++var3) {
			BookCopy c = var5[var3];
			retVal.add(c.getCopyNum());
		}

		return retVal;
	}

	public void addCopy() {
		BookCopy[] newArr = new BookCopy[this.copies.length + 1];
		System.arraycopy(this.copies, 0, newArr, 0, this.copies.length);
		newArr[this.copies.length] = new BookCopy(this, this.copies.length + 1, true);
		this.copies = newArr;
	}

	public boolean equals(Object ob) {
		if (ob == null) {
			return false;
		} else if (ob.getClass() != this.getClass()) {
			return false;
		} else {
			Book b = (Book) ob;
			return b.isbn.equals(this.isbn);
		}
	}

	public boolean isAvailable() {
		return this.copies == null ? false : (Boolean) Arrays.stream(this.copies).map((l) -> {
			return l.isAvailable();
		}).reduce(false, (x, y) -> {
			return x || y;
		});
	}

	public String toString() {
		String var10000 = this.isbn;
		return "isbn: " + var10000 + ", maxLength: " + this.maxCheckoutLength + ", available: " + this.isAvailable();
	}

	public int getNumCopies() {
		return this.copies.length;
	}

	public String getTitle() {
		return this.title;
	}

	public BookCopy[] getCopies() {
		return this.copies;
	}

	public List<Author> getAuthors() {
		return this.authors;
	}

	public String getIsbn() {
		return this.isbn;
	}

	public BookCopy getNextAvailableCopy() {
		Optional<BookCopy> optional = Arrays.stream(this.copies).filter((x) -> {
			return x.isAvailable();
		}).findFirst();
		if (optional.isPresent()){
			BookCopy[] newArr = new BookCopy[this.copies.length - 1];
			System.arraycopy(this.copies, 0, newArr, 0, this.copies.length-1);
			if (this.copies.length-1>0) {
				newArr[this.copies.length - 1] = new BookCopy(this, this.copies.length - 1, true);
			}
			this.copies = newArr;
		}
		return optional.isPresent() ? (BookCopy) optional.get() : null;
	}

	public BookCopy getCopy(int copyNum) {
		BookCopy[] var5;
		int var4 = (var5 = this.copies).length;
		for (int var3 = 0; var3 < var4; ++var3) {
			BookCopy c = var5[var3];
			if (copyNum == c.getCopyNum()) {
				return c;
			}
		}

		return null;
	}

	public int getMaxCheckoutLength() {
		return this.maxCheckoutLength;
	}

}

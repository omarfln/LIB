package librarysystem;

import components.CustomButton;
import controllers.SystemController;
import dataaccess.Auth;
import librarysystem.adminscreens.books.AddBook;
import librarysystem.adminscreens.books.AddCopy;
import librarysystem.librarienscreens.checkouts.CheckOutBook;
import librarysystem.librarienscreens.checkouts.CheckoutRecord;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class MainLayout extends JFrame {
    public static final MainLayout INSTANCE = new MainLayout();
    private JPanel navMenueButtonsPanal;
    private JPanel mainCanvas;

    private MainLayout() {
        this.setTitle("Library System");
        this.setDefaultCloseOperation(3);
        JSplitPane splitPane = this.mainLayout();
        splitPane.setLeftComponent(this.sideMenue());
        this.mainCanvas = this.mainCanvas();
        splitPane.setRightComponent(this.mainCanvas);
        splitPane.setOneTouchExpandable(true);
        this.add(splitPane);
        this.setSize(1000, 1000);
        this.setLocationRelativeTo((Component) null);
        this.setVisible(true);
    }

    public void init(Auth auth) {
        this.populateNavMenuByAuth(SystemController.currentAuth);
        this.setVisible(true);
    }

    private JSplitPane mainLayout() {
        JSplitPane splitPane = new JSplitPane(1);
        splitPane.setContinuousLayout(true);
        splitPane.setAutoscrolls(true);
        splitPane.setEnabled(false);
        splitPane.setDividerSize(10);
        splitPane.setDividerLocation(300);
        return splitPane;
    }

    private JPanel sideMenue() {
        JPanel sideMenue = new JPanel();
        sideMenue.setLayout(new BorderLayout());
        sideMenue.setBackground(Color.WHITE);
        sideMenue.setSize(500, 1000);
        sideMenue.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
        JPanel logoPanel = new JPanel();
        logoPanel.setLayout(new BorderLayout(10, 10));
        logoPanel.setSize(500, 100);
        sideMenue.add(logoPanel, "North");

        this.navMenueButtonsPanal = new JPanel();
        this.navMenueButtonsPanal.setLayout(new BoxLayout(this.navMenueButtonsPanal, 1));
        this.navMenueButtonsPanal.setBackground(new Color(229, 238, 235));
        this.navMenueButtonsPanal.setBorder(new EmptyBorder(30, 1, 1, 1));
        this.navMenueButtonsPanal.setAlignmentX(Component.CENTER_ALIGNMENT);
        this.navMenueButtonsPanal.setPreferredSize(new Dimension(200, 500));
        this.navMenueButtonsPanal.setSize(new Dimension(200, 500));

        sideMenue.add(this.navMenueButtonsPanal, "Center");
        JPanel bottomPanel = new JPanel();
        bottomPanel.setBackground(new Color(0, 200, 0));
        bottomPanel.setLayout(new BorderLayout(0, 0));
        bottomPanel.setSize(500, 100);
        sideMenue.add(bottomPanel, "South");
        return sideMenue;
    }

    private JPanel mainCanvas() {
        JPanel rightPanal = new JPanel();
        rightPanal.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
        rightPanal.setBackground(new Color(255, 255, 255));
        rightPanal.setLayout(new BorderLayout(0, 0));
        rightPanal.setSize(500, 1000);

        ImageIcon image = new ImageIcon(this.backGroundImagePath());

        rightPanal.add(new JLabel(image));
        return rightPanal;
    }

    private void populateNavMenuByAuth(Auth auth) {
        this.navMenueButtonsPanal.removeAll();
        switch (auth) {
            case ADMIN:
                this.populateAdminNavMenu();
                break;
            case LIBRARIAN:
                this.populateLibrarianNavMenu();
                break;
            case BOTH:
                this.populateAdminNavMenu();
                this.populateLibrarianNavMenu();
        }

    }

    private void populateAdminNavMenu() {
        CustomButton addMemberBtn = new CustomButton("Add Library Member", 170, 40, new Color(209, 209, 209));
        addMemberBtn.setMaximumSize(new Dimension(getWidth(), 40));
        CustomButton editMemberBtn = new CustomButton("Edit Library Member", 170, 40, new Color(209, 209, 209));
        editMemberBtn.setMaximumSize(new Dimension(getWidth(), 40));
        CustomButton addBookCopyBtn = new CustomButton("Add Book Copy", 170, 40, new Color(209, 209, 209));
        addBookCopyBtn.setMaximumSize(new Dimension(getWidth(), 40));
        CustomButton addBookBtn = new CustomButton("Add Book", 170, 40, new Color(209, 209, 209));
        addBookBtn.setMaximumSize(new Dimension(getWidth(), 40));
        addMemberBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                MainLayout.this.mainCanvas.removeAll();
                AddMemberWindow.INSTANCE.init();
                AddMemberWindow.INSTANCE.setVisible(true);
                MainLayout.this.mainCanvas.add(AddMemberWindow.INSTANCE);
                validate();
                repaint();
            }
        });

        editMemberBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                MainLayout.this.mainCanvas.removeAll();
                EditMemberWindow.INSTANCE.init();
                EditMemberWindow.INSTANCE.setVisible(true);
                MainLayout.this.mainCanvas.add(EditMemberWindow.INSTANCE);
                validate();
                repaint();
            }
        });

        addBookCopyBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                MainLayout.this.mainCanvas.removeAll();
                AddCopy.INSTANCE.init();
                AddCopy.INSTANCE.setVisible(true);
                MainLayout.this.mainCanvas.add(AddCopy.INSTANCE);
                validate();
                repaint();
            }
        });
        addBookBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                MainLayout.this.mainCanvas.removeAll();
                AddBook.INSTANCE.init();
                AddBook.INSTANCE.setVisible(true);
                MainLayout.this.mainCanvas.add(AddBook.INSTANCE);
                validate();
                repaint();
            }
        });
        this.navMenueButtonsPanal.add(addMemberBtn);
        this.navMenueButtonsPanal.add(editMemberBtn);
        this.navMenueButtonsPanal.add(addBookCopyBtn);
        this.navMenueButtonsPanal.add(addBookBtn);
    }

    private void populateLibrarianNavMenu() {
        JButton checkOutBookBtn = new CustomButton("Checkout Book", 200, 40, new Color(209, 209, 209));
        JButton printMemberCheckOutRecordBtn = new CustomButton("Checkout Records ", 200, 40,
                new Color(209, 209, 209));

        checkOutBookBtn.setMaximumSize(new Dimension(getWidth(), 40));
        printMemberCheckOutRecordBtn.setMaximumSize(new Dimension(getWidth(), 40));

        checkOutBookBtn.addActionListener(e -> {
            System.out.println("Check Out Book");
            this.mainCanvas.removeAll();
            this.mainCanvas.add(CheckOutBook.INSTANCE);
            this.mainCanvas.getComponent(0).revalidate();
            this.mainCanvas.getComponent(0).repaint();
        });

        printMemberCheckOutRecordBtn.addActionListener(e -> {
            System.out.println("Check Out Records");
            this.mainCanvas.removeAll();
            this.mainCanvas.add(CheckoutRecord.INSTANCE);
            this.mainCanvas.getComponent(0).revalidate();
            this.mainCanvas.getComponent(0).repaint();
        });

        this.navMenueButtonsPanal.add(checkOutBookBtn);
        this.navMenueButtonsPanal.add(printMemberCheckOutRecordBtn);
    }

    private String backGroundImagePath() {
        String currDirectory = System.getProperty("user.dir");
        String fileSep = System.getProperty("file.separator");
        return currDirectory + fileSep + "src" + fileSep + "librarysystem" + fileSep + "library.jpg";
    }

}

package librarysystem.librarienscreens.checkouts;

import java.awt.Dimension;
import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JPanel;
import javax.swing.JTable;
import java.awt.Component;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.table.TableCellRenderer;
import javax.swing.SwingConstants;
import javax.swing.JTextArea;
import components.CustomButton;
import controllers.SystemController;
import dataaccess.DataAccessFacade;
import payloads.AddCheckoutRecordPayload;

public class CheckOutBook extends JPanel {

    private DataAccessFacade da = new DataAccessFacade();

    public static final CheckOutBook INSTANCE = new CheckOutBook();
    private JTextField memberID = new JTextField();
    private JTextField bookIsbn = new JTextField();

    private JLabel lHeader;
    private JLabel labelID;
    private JLabel isbnLabel;
    private JButton checkoutButton;

    private JLabel errorLabel;

    private AddCheckoutRecordPayload responsePayload;

    /**
     * Create the panel.
     */
    private CheckOutBook() {
        setBackground(new Color(243, 248, 246));
        setLayout(null);
        setPreferredSize(new Dimension(600, 600));
        SystemController ci = new SystemController();

        JLabel errorLabel = new JLabel("");
        errorLabel.setForeground(Color.RED);
        errorLabel.setBounds(160, 80, 200, 60);
        errorLabel.setVisible(false);
        add(errorLabel);

        JLabel successLabel = new JLabel("");
        successLabel.setForeground(Color.GREEN);
        successLabel.setBounds(160, 80, 200, 60);
        successLabel.setVisible(false);
        add(successLabel);

        lHeader = new JLabel("Checkout Book");
        lHeader.setFont(new Font("Serif", Font.BOLD, 24));
        lHeader.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lHeader.setBounds(10, 10, 584, 60);
        add(lHeader);

        labelID = new JLabel("Member ID");
        labelID.setBounds(10, 129, 77, 13);
        add(labelID);

        memberID.setBounds(91, 126, 198, 21);
        add(memberID);

        isbnLabel = new JLabel("ISBN");
        isbnLabel.setHorizontalAlignment(SwingConstants.RIGHT);
        isbnLabel.setBounds(301, 129, 28, 13);
        add(isbnLabel);

        checkoutButton = new CustomButton("Checkout", 170, 40, new Color(181, 229, 134));
        checkoutButton.setBounds(424, 171, 170, 40);
        checkoutButton.addActionListener(e -> {
            String memberId = memberID.getText();
            String book = bookIsbn.getText();
            System.out.println("Member: " + memberId);
            System.out.println("book: " + book);

            try {
                responsePayload = da.addRecord(memberId, book);
                if (!responsePayload.isSuccess()) {
                    successLabel.setVisible(false);
                    errorLabel.setText(responsePayload.getMessage());
                    errorLabel.setVisible(true);
                } else {
                    errorLabel.setVisible(false);
                    successLabel.setVisible(true);
                    successLabel.setText(responsePayload.getMessage());
                    memberID.setText("");
                    bookIsbn.setText("");
                }

                System.out.println(responsePayload.isSuccess());
                System.out.println(responsePayload.getMessage());

            } catch (Exception exception) {
                exception.printStackTrace();
            }

        });

        add(checkoutButton);

        bookIsbn.setBounds(341, 126, 253, 21);
        add(bookIsbn);
    }

    public CheckOutBook init() {
        CheckOutBook panel;
        panel = new CheckOutBook();
        panel.setVisible(true);
        return panel;
    }

    class TextAreaRenderer extends JTextArea implements TableCellRenderer {
        public TextAreaRenderer() {
            setLineWrap(true);
            setWrapStyleWord(true);
        }

        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus,
                int row, int column) {
            setText((String) value);
            setSize(table.getColumnModel().getColumn(column).getWidth(), getPreferredSize().height);
            if (table.getRowHeight(row) != getPreferredSize().height) {
                table.setRowHeight(row, getPreferredSize().height);
            }
            return this;
        }
    }

    class TextAreaEditor extends DefaultCellEditor {
        protected JTextArea textArea;

        public TextAreaEditor() {
            super(new JTextField());
            textArea = new JTextArea();
            textArea.setLineWrap(true);
            textArea.setWrapStyleWord(true);
            textArea.setBorder(null);
        }

        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row,
                int column) {
            textArea.setText((String) value);
            return textArea;
        }

        public Object getCellEditorValue() {
            return textArea.getText();
        }
    }

    public static CheckOutBook getInstance() {
        return new CheckOutBook();
    }
}

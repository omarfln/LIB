package librarysystem.librarienscreens.checkouts;

import business.CheckoutCopyRecord;
import business.LibraryMember;
import components.CustomButton;
import controllers.SystemController;
import dataaccess.DataAccessFacade;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class CheckoutRecord extends JPanel {

    public static final CheckoutRecord INSTANCE = new CheckoutRecord();
    public DataAccessFacade da = new DataAccessFacade();
    private JLabel pageHeader;
    private JLabel ddlLabel;
    private JComboBox membersIdsDDl;

    private JLabel booksDDlLabel;

    private JButton deleteButton = new JButton();

    private JComboBox booksDDl;
    private JButton searchButton;
    private JScrollPane contentPane;

    private JCheckBox onlyOverDue;

    private JTable tableContent;

    private String[] columnNames = { "checkoutId", "memberId", "book ISBN", "checkout Date", "due Date" };

    private String selectedBook = null;
    private String selectedMemberId = null;
    private boolean overDueValue = false;

    private int[] selectedRows;

    private void loadData() {
        List<CheckoutCopyRecord> records = new ArrayList<>();
        if (selectedMemberId == "All")
            selectedMemberId = null;
        if (selectedBook == "All")
            selectedBook = null;

        try {
            records = da.getCheckoutRecords(selectedMemberId, selectedBook, overDueValue);
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        System.out.println("records :");
        System.out.println(records);

        DefaultTableModel model = new DefaultTableModel(columnNames, 0);

        for (CheckoutCopyRecord record : records) {
            model.addRow(List.of(record.getId(), record.getMember().getMemberId(), record.getCopy().getBook().getIsbn(),
                    record.getLandingDate().toString(), record.getDueDate().toString()).toArray());
        }
        tableContent.setModel(model);
    }

    private CheckoutRecord() {
        SystemController systemController = new SystemController();
        setBackground(new Color(255, 255, 255));
        setLayout(null);
        setPreferredSize(new Dimension(500, 500));

        pageHeader = new JLabel("Checkout Records");
        pageHeader.setFont(new Font("Serif", Font.BOLD, 24));
        pageHeader.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        pageHeader.setBounds(20, 10, 500, 60);
        add(pageHeader);

        ddlLabel = new JLabel("Select Memeber ID");
        ddlLabel.setBounds(20, 60, 200, 30);
        add(ddlLabel);

        List<LibraryMember> members = systemController.getAllMembers();
        List<String> memberStrings = new ArrayList<>();
        memberStrings.add("All");
        memberStrings
                .addAll(members.stream().map(x -> "" + x.getMemberId() + "/" + x.getFirstName() + " " + x.getLastName())
                        .collect(Collectors.toList()));
        membersIdsDDl = new JComboBox(memberStrings.toArray());

        membersIdsDDl.setBounds(20, 90, 200, 30);
        add(membersIdsDDl);

        booksDDlLabel = new JLabel("Select Book");
        booksDDlLabel.setBounds(280, 60, 200, 30);
        add(booksDDlLabel);

        List<String> books = new ArrayList<>();
        books.add("All");
        books.addAll(systemController.allBookIds());
        booksDDl = new JComboBox(books.toArray());
        booksDDl.setBounds(280, 90, 200, 30);
        add(booksDDl);

        onlyOverDue = new JCheckBox("Only OverDue Date");
        onlyOverDue.setBounds(20, 120, 200, 30);
        add(onlyOverDue);

        deleteButton.setBounds(20, 150, 200, 30);
        deleteButton.setBackground(Color.red);

        deleteButton.setVisible(false);

        add(deleteButton);

        deleteButton.addActionListener(e -> {
            System.out.println("Delete record");
        });

        searchButton = new CustomButton("Search", 150, 100, new Color(181, 219, 255));
        searchButton.setBounds(500, 150, 100, 30);
        add(searchButton);

        searchButton.addActionListener(e -> {

            selectedMemberId = membersIdsDDl.getSelectedItem().toString().split("/")[0];
            selectedBook = booksDDl.getSelectedItem().toString();
            overDueValue = onlyOverDue.isSelected();
            loadData();
        });

        contentPane = new JScrollPane();
        contentPane.setBounds(20, 190, 600, 600);
        add(contentPane);

        tableContent = new JTable();
        contentPane.setViewportView(tableContent);

        tableContent.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent lse) {
                if (!lse.getValueIsAdjusting()) {
                    selectedRows = tableContent.getSelectedRows();
                    deleteButton.setText("Delete selected (" + selectedRows.length + ")");
                    if (selectedRows.length == 0)
                        deleteButton.setVisible(false);
                    else
                        deleteButton.setVisible(true);

                }
            }
        });
        loadData();
        setVisible(true);

    }

}

package librarysystem;

import business.LibraryMember;
import business.LibrarySystemException;
import components.CustomButton;
import controllers.ControllerInterface;
import controllers.SystemController;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class AddMemberWindow extends JPanel implements LibWindow {
        private static final long serialVersionUID = 1L;
        public static final AddMemberWindow INSTANCE = new AddMemberWindow();

        ControllerInterface ci = new SystemController();
        private boolean isInitialized = false;

        private JButton BackButton;
        private JTextField cityField;

        private JLabel cityLabel;
        private JTextField firstNameField;
        private JLabel firstNameLabel;
        private JComboBox<String> stateCombo;
        private JLabel titleLabel;
        private JTextField lastNameField;
        private JLabel lastNameLabel;
        private JLabel memberIdLabel;
        private JTextField phoneField;
        private JLabel phoneLabel;
        private JButton saveButton;
        private JLabel stateLabel;
        private JTextField streetField;
        private JLabel streetLabel;
        private JTextField zipCodeField;
        private JLabel zipCodeLabel;

        private void initComponents() {

                titleLabel = new JLabel();
                memberIdLabel = new JLabel();
                firstNameLabel = new JLabel();
                lastNameField = new JTextField();
                lastNameLabel = new JLabel();
                firstNameField = new JTextField(10);
                phoneLabel = new JLabel();
                phoneField = new JTextField();
                streetLabel = new JLabel();
                streetField = new JTextField();
                cityLabel = new JLabel();
                cityField = new JTextField();
                stateLabel = new JLabel();
                stateCombo = new JComboBox<>();
                zipCodeLabel = new JLabel();
                zipCodeField = new JTextField();
                BackButton = new CustomButton("Back", 170, 40, new Color(181, 219, 255));
                saveButton = new CustomButton("Save", 170, 40, new Color(181, 219, 255));

                setBackground(new Color(243, 248, 246));
                titleLabel.setFont(new Font("Serif", Font.BOLD, 24));
                titleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                titleLabel.setText("Add New Library Member");
                titleLabel.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
                memberIdLabel.setFont(new java.awt.Font("Arial", 0, 13));
                memberIdLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                firstNameLabel.setText("First Name");
                lastNameLabel.setText("Last Name");
                phoneLabel.setText("Phone");
                streetLabel.setText("Street");
                cityLabel.setText("City");
                stateLabel.setText("State");
                stateCombo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "AL", "AK", "AS", "AZ", "AR",
                                "CA", "CO", "CT", "DE", "DC", "FL", "GA", "GU", "HI", "ID", "IL", "IN", "IA", "KS",
                                "KY", "LA", "ME", "MD", "MA", "MI", "MN", "MS", "MO", "MT", "NE", "NV", "NH", "NJ",
                                "NM", "NY", "NC", "ND", "MP", "OH", "OK", "OR", "PA", "PR", "RI", "SC", "SD", "TN",
                                "TX", "UT", "VT", "VA", "VI", "WA", "WV", "WI", "WY" }));
                zipCodeLabel.setText("Zip Code");
                zipCodeField.setToolTipText("");
                BackButton.setVisible(false);
                BackButton.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                                BackButtonActionPerformed(evt);
                        }
                });

                saveButton.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                                saveButtonActionPerformed(evt);
                        }
                });

                JPanel panel = new JPanel();
                panel.setSize(600, 600);
                panel.setBackground(new Color(243, 248, 246));
                GroupLayout layout = new GroupLayout(panel);
                panel.setLayout(layout);
                this.add(panel);

                layout.setHorizontalGroup(
                                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addGroup(layout.createSequentialGroup()
                                                                .addGroup(layout.createParallelGroup(
                                                                                javax.swing.GroupLayout.Alignment.LEADING)
                                                                                .addComponent(titleLabel,
                                                                                                javax.swing.GroupLayout.Alignment.TRAILING,
                                                                                                javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                                                javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                                                Short.MAX_VALUE)
                                                                                .addGroup(layout.createSequentialGroup()
                                                                                                .addGap(249, 249, 249)
                                                                                                .addComponent(memberIdLabel,
                                                                                                                javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                                                                javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                                                                Short.MAX_VALUE)
                                                                                                .addGap(0, 0, Short.MAX_VALUE)))
                                                                .addContainerGap())
                                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout
                                                                .createSequentialGroup()
                                                                .addGap(26, 26, 26)
                                                                .addGroup(layout.createParallelGroup(
                                                                                javax.swing.GroupLayout.Alignment.TRAILING)
                                                                                .addGroup(layout.createSequentialGroup()
                                                                                                .addComponent(firstNameLabel)
                                                                                                .addGap(18, 18, 18)
                                                                                                .addComponent(firstNameField,
                                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE,
                                                                                                                150,
                                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE))
                                                                                .addGroup(layout.createSequentialGroup()
                                                                                                .addGroup(layout.createParallelGroup(
                                                                                                                javax.swing.GroupLayout.Alignment.TRAILING)
                                                                                                                .addComponent(streetLabel)
                                                                                                                .addComponent(phoneLabel)
                                                                                                                .addComponent(stateLabel))
                                                                                                .addGap(45, 45, 45)
                                                                                                .addGroup(layout.createParallelGroup(
                                                                                                                javax.swing.GroupLayout.Alignment.TRAILING,
                                                                                                                false)
                                                                                                                .addComponent(phoneField,
                                                                                                                                javax.swing.GroupLayout.Alignment.LEADING,
                                                                                                                                javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                                                                                150,
                                                                                                                                Short.MAX_VALUE)
                                                                                                                .addComponent(streetField,
                                                                                                                                javax.swing.GroupLayout.Alignment.LEADING,
                                                                                                                                javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                                                                                150,
                                                                                                                                Short.MAX_VALUE)
                                                                                                                .addComponent(stateCombo,
                                                                                                                                javax.swing.GroupLayout.Alignment.LEADING,
                                                                                                                                0,
                                                                                                                                javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                                                                                Short.MAX_VALUE))))
                                                                .addPreferredGap(
                                                                                javax.swing.LayoutStyle.ComponentPlacement.RELATED,
                                                                                100, Short.MAX_VALUE)
                                                                .addGroup(layout.createParallelGroup(
                                                                                javax.swing.GroupLayout.Alignment.LEADING)
                                                                                .addComponent(BackButton,
                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE,
                                                                                                131,
                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                                .addGroup(layout.createParallelGroup(
                                                                                                javax.swing.GroupLayout.Alignment.LEADING,
                                                                                                false)
                                                                                                .addGroup(layout.createSequentialGroup()
                                                                                                                .addComponent(lastNameLabel)
                                                                                                                .addPreferredGap(
                                                                                                                                javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                                                                                .addComponent(lastNameField,
                                                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE,
                                                                                                                                150,
                                                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE))
                                                                                                .addGroup(layout.createSequentialGroup()
                                                                                                                .addComponent(cityLabel)
                                                                                                                .addPreferredGap(
                                                                                                                                javax.swing.LayoutStyle.ComponentPlacement.RELATED,
                                                                                                                                javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                                                                                Short.MAX_VALUE)
                                                                                                                .addComponent(cityField,
                                                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE,
                                                                                                                                150,
                                                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE)))
                                                                                .addGroup(layout.createSequentialGroup()
                                                                                                .addComponent(zipCodeLabel)
                                                                                                .addGap(18, 18, 18)
                                                                                                .addComponent(zipCodeField,
                                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE,
                                                                                                                150,
                                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE)))
                                                                .addGap(112, 112, 112))
                                                .addGroup(layout.createParallelGroup(
                                                                javax.swing.GroupLayout.Alignment.LEADING)
                                                                .addGroup(layout.createSequentialGroup()
                                                                                .addGap(214, 214, 214)
                                                                                .addComponent(saveButton,
                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE,
                                                                                                131,
                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                                .addContainerGap(346,
                                                                                                Short.MAX_VALUE))));
                layout.setVerticalGroup(
                                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addGroup(layout.createSequentialGroup()
                                                                .addContainerGap()
                                                                .addComponent(titleLabel)
                                                                .addGap(18, 18, 18)
                                                                .addComponent(memberIdLabel)
                                                                .addGap(26, 26, 26)
                                                                .addGroup(layout.createParallelGroup(
                                                                                javax.swing.GroupLayout.Alignment.BASELINE)
                                                                                .addComponent(lastNameField,
                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE,
                                                                                                javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                                .addComponent(lastNameLabel)
                                                                                .addComponent(firstNameLabel)
                                                                                .addComponent(firstNameField,
                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE,
                                                                                                javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE))
                                                                .addGap(18, 18, 18)
                                                                .addGroup(layout.createParallelGroup(
                                                                                javax.swing.GroupLayout.Alignment.BASELINE)
                                                                                .addComponent(phoneLabel)
                                                                                .addComponent(phoneField,
                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE,
                                                                                                javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE))
                                                                .addGap(27, 27, 27)
                                                                .addGroup(layout.createParallelGroup(
                                                                                javax.swing.GroupLayout.Alignment.BASELINE)
                                                                                .addComponent(streetLabel)
                                                                                .addComponent(streetField,
                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE,
                                                                                                javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                                .addComponent(cityLabel)
                                                                                .addComponent(cityField,
                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE,
                                                                                                javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE))
                                                                .addPreferredGap(
                                                                                javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                                .addGroup(layout.createParallelGroup(
                                                                                javax.swing.GroupLayout.Alignment.BASELINE)
                                                                                .addComponent(stateLabel)
                                                                                .addComponent(stateCombo,
                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE,
                                                                                                javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                                .addComponent(zipCodeLabel)
                                                                                .addComponent(zipCodeField,
                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE,
                                                                                                javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE))
                                                                .addPreferredGap(
                                                                                javax.swing.LayoutStyle.ComponentPlacement.RELATED,
                                                                                74, Short.MAX_VALUE)
                                                                .addComponent(BackButton)
                                                                .addGap(51, 51, 51))
                                                .addGroup(layout.createParallelGroup(
                                                                javax.swing.GroupLayout.Alignment.LEADING)
                                                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING,
                                                                                layout.createSequentialGroup()
                                                                                                .addContainerGap(300,
                                                                                                                Short.MAX_VALUE)
                                                                                                .addComponent(saveButton)
                                                                                                .addGap(50, 50, 50))));
        }

        private void BackButtonActionPerformed(ActionEvent evt) {
                LibrarySystem.INSTANCE.setVisible(true);
        }

        private void saveButtonActionPerformed(ActionEvent evt) {
                try {

                        LibraryMember member = ci.addMember(firstNameField.getText(), lastNameField.getText(),
                                        phoneField.getText(), streetField.getText(), cityField.getText(),
                                        stateCombo.getSelectedItem().toString(), zipCodeField.getText());
                        memberIdLabel.setText("Member ID: " + member.getMemberId());
                        JOptionPane.showMessageDialog(AddMemberWindow.this,
                                        "Library member successfully added, Member ID:" + member.getMemberId(), "",
                                        JOptionPane.INFORMATION_MESSAGE);
                        saveButton.setEnabled(false);
                } catch (LibrarySystemException e) {

                        JOptionPane.showMessageDialog(AddMemberWindow.this, e.getMessage(), "Error",
                                        JOptionPane.ERROR_MESSAGE);
                }
        }

        @Override
        public void init() {

                if (!isInitialized) {
                        initComponents();

                        isInitialized = true;
                } else {
                        firstNameField.setText("");
                        lastNameField.setText("");
                        phoneField.setText("");
                        streetField.setText("");
                        cityField.setText("");
                        stateCombo.setSelectedIndex(0);
                        zipCodeField.setText("");
                        saveButton.setEnabled(true);

                }

        }

        @Override
        public boolean isInitialized() {
                return false;
        }

        @Override
        public void isInitialized(boolean val) {

        }
}

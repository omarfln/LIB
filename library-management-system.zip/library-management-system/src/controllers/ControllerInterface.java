package controllers;

import business.*;

import java.util.List;

public interface ControllerInterface {

	String MEMBER_ERR1 = "All the fields are mandatory";
	String MEMBER_ERR2 = "Member ID`s already exists";
	String MEMBER_ERR3 = "Library member doesnt exists";
	String MEMBER_ERR4 = "Telephone and Zip code must be numeric";
	final static String MEMBER_ERR5 = "Book doesnt exists";
	final static String MEMBER_ERR6 = "Book already exists";

	void login(String id, String password) throws LoginException;

	List<String> allMemberIds();

	List<String> allBookIds();

	LibraryMember findMemberById(String id) throws LibrarySystemException;

	LibraryMember addMember(String firstName, String lastName, String telephone,
			String street, String city, String state, String zip) throws LibrarySystemException;

	void editMember(String memberId, String firstName, String lastName, String telephone,
			String street, String city, String state, String zip) throws LibrarySystemException;

	Boolean isBookExist(String isbn);

	Book findBookByIsbn(String isbn) throws LibrarySystemException;

	void addBook(String isbn, String title, int maxCheckoutLength, List<Author> authors) throws LibrarySystemException;

	Author addAuthor(String f, String l, String t, String street, String city, String state, String zip, String bio);

	void addCopyofAnExistingBook(String isbn) throws LibrarySystemException;

}

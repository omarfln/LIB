package controllers;

import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import business.*;
import dataaccess.Auth;
import dataaccess.DataAccess;
import dataaccess.DataAccessFacade;
import dataaccess.User;
import librarysystem.*;
import librarysystem.Main;
import librarysystem.librarienscreens.checkouts.CheckoutRecord;

import javax.swing.*;

public class SystemController implements ControllerInterface {
	public static Auth currentAuth = null;
	DataAccess da = new DataAccessFacade();

	public void login(String id, String password) throws LoginException {

		HashMap<String, User> map = da.readUserMap();
		if (!map.containsKey(id)) {
			throw new LoginException("ID " + id + " not found");
		}
		String passwordFound = map.get(id).getPassword();
		if (!passwordFound.equals(password)) {
			throw new LoginException("Password incorrect");
		}
		currentAuth = map.get(id).getAuthorization();
		LibrarySystem.hideAllWindows();
		startMainFlow();

	}

	private void startMainFlow() {
		EventQueue.invokeLater(() -> {
			MainLayout.INSTANCE.setTitle("Sample Library Application");
			MainLayout.INSTANCE.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

			MainLayout.INSTANCE.init(Auth.BOTH);
			Main.centerFrameOnDesktop(MainLayout.INSTANCE);
			MainLayout.INSTANCE.setVisible(true);
		});
	}

	@Override
	public List<String> allMemberIds() {
		DataAccess da = new DataAccessFacade();
		List<String> retval = new ArrayList<>();
		retval.addAll(da.readMemberMap().keySet());
		return retval;
	}

	public List<String> allMemberIdsAndNames() {
		List<String> members = new ArrayList<>();
		for (LibraryMember member : da.readMemberMap().values()) {
			members.add(member.getFirstName() + " " + member.getLastName() + " id =" + member.getMemberId());
		}
		return members;
	}

	@Override
	public List<String> allBookIds() {
		DataAccess da = new DataAccessFacade();
		List<String> retval = new ArrayList<>();
		retval.addAll(da.readBooksMap().keySet());
		return retval;
	}

	@Override
	public LibraryMember findMemberById(String id) throws LibrarySystemException {
		LibraryMember localMember = null;
		HashMap<String, LibraryMember> stringLibraryMemberHashMap = da.readMemberMap();
		for (LibraryMember member : stringLibraryMemberHashMap.values()) {
			if (member.getMemberId().equals(id))
				localMember = member;
		}
		if (localMember == null)
			throw new LibrarySystemException(MEMBER_ERR3);
		return localMember;
	}

	@Override
	public LibraryMember addMember(String firstName, String lastName, String telephone, String street, String city,
			String state, String zip) throws LibrarySystemException {
		String memberId = nextMemberId();
		if (checkEmptyFields(firstName, lastName, telephone, street, city, state, zip)) {
			throw new LibrarySystemException(MEMBER_ERR1);
		}
		if (isMemberExist(memberId))
			throw new LibrarySystemException(MEMBER_ERR2);
		if (!Util.isNumeric(telephone.replace("-", "")) || !Util.isNumeric(zip))
			throw new LibrarySystemException(MEMBER_ERR4);
		Address address = new Address(street, city, state, zip);
		LibraryMember member = new LibraryMember(memberId, firstName, lastName, telephone, address);
		da.saveNewMember(member);
		return member;

	}

	@Override
	public void editMember(String memberId, String firstName, String lastName, String telephone, String street,
			String city, String state, String zip) throws LibrarySystemException {
		if (checkEmptyFields(firstName, lastName, telephone, street, city, state, zip)) {
			throw new LibrarySystemException(MEMBER_ERR1);
		}

		if (!Util.isNumeric(telephone.replace("-", "")) || !Util.isNumeric(zip))
			throw new LibrarySystemException(MEMBER_ERR4);

		HashMap<String, LibraryMember> LibraryMemberHashMap = da.readMemberMap();
		LibraryMember member = LibraryMemberHashMap.get(memberId);
		if (member == null)
			throw new LibrarySystemException(MEMBER_ERR3);

		Address address = new Address(street, city, state, zip);
		member = new LibraryMember(memberId, firstName, lastName, telephone, address);

		da.saveNewMember(member);

	}

	private Boolean isMemberExist(String id) {
		HashMap<String, LibraryMember> stringLibraryMemberHashMap = da.readMemberMap();
		for (LibraryMember member : stringLibraryMemberHashMap.values()) {
			if (member.getMemberId().equals(id))
				return true;
		}
		return false;
	}

	private String nextMemberId() {
		HashMap<String, LibraryMember> stringLibraryMemberHashMap = da.readMemberMap();
		Integer maxId = Integer.MIN_VALUE;
		for (LibraryMember member : stringLibraryMemberHashMap.values()) {
			if (maxId < Integer.parseInt(member.getMemberId()))
				maxId = Integer.parseInt(member.getMemberId());
		}
		maxId++;
		return maxId.toString();
	}

	private Boolean checkEmptyFields(String firstName, String lastName, String telephone, String street, String city,
			String state, String zip) {
		if (firstName.isEmpty() || lastName.isEmpty() || telephone.isEmpty() || street.isEmpty()
				|| city.isEmpty() || state.isEmpty() || zip.isEmpty())
			return true;
		return false;

	}

	public List<CheckoutRecord> findMemberCheckoutRecordsById(String memberId) {
		System.out.println(memberId);
		return new ArrayList<>();
	}

	public List<LibraryMember> getAllMembers() {
		return da.readMemberMap().values().stream().toList();
	}

	@Override
	public Book findBookByIsbn(String isbn) throws LibrarySystemException {
		Book localBook = null;
		HashMap<String, Book> stringBookHashMap = da.readBooksMap();
		for (Book book : stringBookHashMap.values()) {
			if (book.getIsbn().equals(isbn))
				localBook = book;
		}
		if (localBook == null)
			throw new LibrarySystemException(MEMBER_ERR5);
		return localBook;
	}

	@Override
	public void addBook(String isbn, String title, int maxCheckoutLength, List<Author> authors)
			throws LibrarySystemException {
		if (isbn.isEmpty() || title.isEmpty() || authors.isEmpty()) {
			throw new LibrarySystemException(MEMBER_ERR1);
		}
		if (isBookExist(isbn))
			throw new LibrarySystemException(MEMBER_ERR6);

		Book book = new Book(isbn, title, maxCheckoutLength, authors);
		da.saveNewBook(book);
	}

	@Override
	public Author addAuthor(String f, String l, String t, String street, String city, String state, String zip,
			String bio) {
		Address address = new Address(street, city, state, zip);
		Author author = new Author(f, l, t, address, bio);
		return author;
	}

	@Override
	public Boolean isBookExist(String isbn) {
		HashMap<String, Book> stringBookHashMap = da.readBooksMap();
		for (Book book : stringBookHashMap.values()) {
			if (book.getIsbn().equals(isbn))
				return true;
		}
		return false;

	}

	@Override
	public void addCopyofAnExistingBook(String isbn) throws LibrarySystemException {
		Book localBook = findBookByIsbn(isbn);
		localBook.addCopy();
		da.saveNewBook(localBook);
	}

}
